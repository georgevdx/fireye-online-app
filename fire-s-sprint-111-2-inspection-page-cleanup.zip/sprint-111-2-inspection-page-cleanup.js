/* Fire-S Sprint 111.2 - Inspection Page Cleanup
   Keeps operational inspection pages clean by removing/hiding management analytics panels
   from the normal inspection workflow. Analytics remains the single place for statistics,
   comparison, trends, category performance and AI-ready summaries. */
(function () {
  'use strict';

  const VERSION = '111.2-inspection-page-cleanup';

  const ANALYTICS_PANEL_IDS = [
    'sprint1092ComparisonPanel',
    'sprint1093TrendPanel',
    'sprint1100AIAssistPanel',
    'sprint1101DashboardPanel',
    'sprint1102ActionGroupingPanel'
  ];

  const ANALYTICS_CLASS_SELECTORS = [
    '.s1092-comparison-panel',
    '.s1093-trend-panel',
    '.s1100-ai-assist-panel',
    '.s1101-dashboard-panel',
    '.s1102-action-grouping-panel'
  ];

  function injectCleanupStyles() {
    if (document.getElementById('s1112InspectionCleanupStyles')) return;

    const style = document.createElement('style');
    style.id = 's1112InspectionCleanupStyles';
    style.textContent = `
      /* Sprint 111.2: operational pages must not show management analytics panels. */
      #projectFormSection > #sprint1092ComparisonPanel,
      #projectFormSection > #sprint1093TrendPanel,
      #projectFormSection > #sprint1100AIAssistPanel,
      #projectFormSection > #sprint1101DashboardPanel,
      #projectFormSection > #sprint1102ActionGroupingPanel,
      #projectFormSection .s1092-comparison-panel,
      #projectFormSection .s1093-trend-panel,
      #projectFormSection .s1100-ai-assist-panel,
      #projectFormSection .s1101-dashboard-panel,
      #projectFormSection .s1102-action-grouping-panel {
        display: none !important;
      }

      .s1112-operations-note {
        margin-top: 8px;
        color: #64748b;
        font-size: 0.88rem;
      }
    `;
    document.head.appendChild(style);
  }

  function isInsideAnalytics(element) {
    return !!(element && element.closest && element.closest('#analyticsSection, #analyticsContent'));
  }

  function cleanupInspectionPage() {
    ANALYTICS_PANEL_IDS.forEach(id => {
      const element = document.getElementById(id);
      if (element && !isInsideAnalytics(element)) {
        element.remove();
      }
    });

    ANALYTICS_CLASS_SELECTORS.forEach(selector => {
      document.querySelectorAll(selector).forEach(element => {
        if (!isInsideAnalytics(element)) element.remove();
      });
    });
  }

  function improveInspectionHeaderText() {
    const checklistCard = document.getElementById('checklistCard');
    if (!checklistCard || checklistCard.dataset.s1112Note === 'true') return;

    const heading = checklistCard.querySelector('h2');
    if (!heading) return;

    const note = document.createElement('div');
    note.className = 's1112-operations-note';
    note.textContent = 'Operational inspection workspace. Statistics, comparison, trends and AI summaries are available under Analytics.';
    heading.insertAdjacentElement('afterend', note);
    checklistCard.dataset.s1112Note = 'true';
  }

  function bindAnalyticsButtonLabel() {
    const btn = document.getElementById('analyticsBtn');
    if (btn && !/Analytics/i.test(btn.textContent || '')) {
      btn.textContent = 'Analytics';
    }
  }

  function runCleanup() {
    injectCleanupStyles();
    cleanupInspectionPage();
    improveInspectionHeaderText();
    bindAnalyticsButtonLabel();
  }

  function wrapOpenProject() {
    const originalOpen = window.openProject;
    if (typeof originalOpen !== 'function' || originalOpen.__s1112Wrapped) return;

    const wrapped = function () {
      const result = originalOpen.apply(this, arguments);
      setTimeout(runCleanup, 250);
      setTimeout(runCleanup, 650);
      setTimeout(runCleanup, 1200);
      return result;
    };

    wrapped.__s1112Wrapped = true;
    window.openProject = wrapped;
  }

  function installObserver() {
    if (window.__fireS1112ObserverInstalled) return;
    window.__fireS1112ObserverInstalled = true;

    const observer = new MutationObserver(() => {
      window.clearTimeout(window.__fireS1112CleanupTimer);
      window.__fireS1112CleanupTimer = window.setTimeout(runCleanup, 80);
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  function install() {
    runCleanup();
    wrapOpenProject();
    installObserver();

    window.FireSInspectionCleanup1112 = {
      version: VERSION,
      cleanup: runCleanup
    };

    console.log('Fire-S Sprint 111.2 installed:', VERSION);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(install, 300));
  } else {
    setTimeout(install, 300);
  }
})();
