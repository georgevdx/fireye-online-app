Fire-S Sprint 111.2 - Inspection Page Cleanup

Purpose:
Keeps the Inspection page operational-only and moves all management/statistical views into Analytics.

Hidden/removed from the Inspection page:
- Inspection Comparison
- Trend Analytics
- Management View cards
- Category Performance
- AI-ready Summary
- Executive/statistical dashboard panels

Operational pages now focus on:
- Checklist
- Notes
- Photos
- Action Register
- Save
- Finish Inspection

Analytics remains the place for:
- Executive Overview
- Inspection Comparison
- Trend Analytics
- Category Performance
- Priority Actions
- AI-ready Summary
- Inspection History

Files added/changed:
- Added sprint-111-2-inspection-page-cleanup.js
- Updated index.html script includes
- Added README-SPRINT-111-2.txt

Notes:
This sprint deliberately does not delete the older comparison/trend/AI modules. It prevents those management panels from rendering on the operational Inspection page, preserving the analytics functionality while reducing clutter for field use.
