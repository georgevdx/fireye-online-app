Fire-S Sprint 106.0 New Inspection Flow

Upload full ZIP contents to GitHub.

Test:
1. Open an existing premises.
2. Click New Inspection.
3. Confirm old answers/photos move to History.
4. Confirm site details stay, but checklist answers and photos reset.
