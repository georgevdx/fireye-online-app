# Fire-S v106.0 New Inspection Flow

- Adds `new-inspection-flow.js`.
- Adds Inspection Control panel on the premises page.
- Allows starting a fresh inspection for an existing premises.
- Archives the current inspection into `inspectionHistory` before resetting the active checklist.
- Keeps fixed premises information such as site name, address, contact and occupancy.
- Clears checklist answers and photos for the new inspection.
