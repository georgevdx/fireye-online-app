// Fire-S v116 Display Recovery Service Worker
// Force network-first for HTML/CSS/JS so GitHub Pages does not keep broken cached files.
const CACHE_NAME = 'fire-s-v116-display-recovery';

self.addEventListener('install', event => {
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);

  if (request.method !== 'GET') return;

  const isAppAsset =
    url.pathname.endsWith('/') ||
    url.pathname.endsWith('/index.html') ||
    url.pathname.endsWith('/styles.css') ||
    url.pathname.endsWith('/app.js') ||
    url.pathname.endsWith('/rc-stability-hotfix.js') ||
    url.pathname.endsWith('/service-worker.js');

  if (isAppAsset) {
    event.respondWith(
      fetch(request, { cache: 'no-store' })
        .catch(() => caches.match(request))
    );
  }
});
