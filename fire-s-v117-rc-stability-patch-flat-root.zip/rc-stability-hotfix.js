/*
  Fire-S RC Stability Hotfix v117
  Goals:
  - Keep display stable by using a separate small hotfix file only.
  - Delete Inspection must never delete the premises shell/history.
  - Add Scheduled Today and Last 5 Completed to the Home Command Centre.
  - Reduce checklist/finding jump behaviour and lock the active inspection context.
*/
(function () {
  'use strict';

  const HOTFIX_VERSION = 'v117-rc-stability';

  function safeProjects() {
    try {
      if (typeof getProjects === 'function') {
        const projects = getProjects();
        return Array.isArray(projects) ? projects : [];
      }
    } catch (error) {
      console.warn('RC117: getProjects failed.', error);
    }

    try {
      const raw = localStorage.getItem('fireyeProjects');
      return raw ? JSON.parse(raw) : [];
    } catch (error) {
      return [];
    }
  }

  function saveProjects(projects) {
    if (typeof setProjects === 'function') {
      setProjects(projects);
      return;
    }
    localStorage.setItem('fireyeProjects', JSON.stringify(projects || []));
  }

  function visibleProjects() {
    const projects = safeProjects();
    try {
      if (typeof getVisibleProjectsForCurrentUser === 'function' && window.currentUserProfile) {
        return getVisibleProjectsForCurrentUser(projects);
      }
    } catch (error) {
      console.warn('RC117: visible project filter failed.', error);
    }
    return projects;
  }

  function todayString() {
    return new Date().toISOString().slice(0, 10);
  }

  function normaliseDate(value) {
    if (!value) return '';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value).slice(0, 10);
    return date.toISOString().slice(0, 10);
  }

  function formatDate(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value || '-';
    return date.toLocaleDateString('en-ZA');
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function projectTitle(project) {
    return (
      project?.siteName ||
      project?.projectName ||
      project?.organisationName ||
      project?.projectAddress ||
      'Unnamed premises'
    );
  }

  function projectClient(project) {
    return project?.organisationName || project?.companyName || project?.clientName || 'Client not recorded';
  }

  function scheduleDate(project) {
    return (
      project?.scheduledDate ||
      project?.followUpDate ||
      project?.nextInspectionDate ||
      ''
    );
  }

  function isCompleted(project) {
    return Boolean(
      project?.completedAt ||
      project?.archivedAt ||
      project?.scheduledStatus === 'completed' ||
      project?.archiveStatus === 'completed'
    );
  }

  function dueToday(project) {
    return !isCompleted(project) && normaliseDate(scheduleDate(project)) === todayString();
  }

  function completedTime(project) {
    return new Date(
      project?.completedAt ||
      project?.archivedAt ||
      project?.lastSaved ||
      project?.inspectionDate ||
      0
    ).getTime() || 0;
  }

  function openInspection(projectId) {
    if (!projectId) return;
    if (typeof openProject === 'function') {
      openProject(projectId);
      return;
    }
    window.currentProjectId = projectId;
  }

  function ensureHomeOperationalPanels() {
    const centre = document.getElementById('mainCommandCentre');
    if (!centre) return null;

    let panel = document.getElementById('rc117OperationalDashboard');
    if (panel) return panel;

    panel = document.createElement('section');
    panel.id = 'rc117OperationalDashboard';
    panel.className = 'rc117-operational-dashboard';
    panel.innerHTML = `
      <div class="rc117-op-card">
        <div class="rc117-op-heading">
          <div>
            <span class="rc117-kicker">Today</span>
            <h3>Scheduled Inspections Today</h3>
          </div>
          <span id="rc117ScheduledCount" class="rc117-count">0</span>
        </div>
        <div id="rc117ScheduledTodayList" class="rc117-list"></div>
      </div>
      <div class="rc117-op-card">
        <div class="rc117-op-heading">
          <div>
            <span class="rc117-kicker">Recent</span>
            <h3>Last 5 Completed Inspections</h3>
          </div>
          <span id="rc117RecentCount" class="rc117-count">0</span>
        </div>
        <div id="rc117RecentlyCompletedList" class="rc117-list"></div>
      </div>
    `;

    const commandGrid = centre.querySelector('.main-command-grid');
    if (commandGrid) {
      commandGrid.parentNode.insertBefore(panel, commandGrid);
    } else {
      centre.appendChild(panel);
    }

    return panel;
  }

  function renderOperationalDashboard() {
    const panel = ensureHomeOperationalPanels();
    if (!panel) return;

    const projects = visibleProjects();
    const scheduledToday = projects
      .filter(dueToday)
      .sort((a, b) => String(projectTitle(a)).localeCompare(String(projectTitle(b))))
      .slice(0, 10);

    const recentlyCompleted = projects
      .filter(isCompleted)
      .sort((a, b) => completedTime(b) - completedTime(a))
      .slice(0, 5);

    const scheduledCount = document.getElementById('rc117ScheduledCount');
    const recentCount = document.getElementById('rc117RecentCount');
    const scheduledList = document.getElementById('rc117ScheduledTodayList');
    const recentList = document.getElementById('rc117RecentlyCompletedList');

    if (scheduledCount) scheduledCount.textContent = scheduledToday.length;
    if (recentCount) recentCount.textContent = recentlyCompleted.length;

    if (scheduledList) {
      scheduledList.innerHTML = scheduledToday.length
        ? scheduledToday.map(project => `
            <button type="button" class="rc117-row" data-open-project="${escapeHtml(project.id)}">
              <span>
                <strong>${escapeHtml(projectTitle(project))}</strong>
                <small>${escapeHtml(projectClient(project))} · ${escapeHtml(project.inspectionNumber || 'No inspection number')}</small>
              </span>
              <em>Open</em>
            </button>
          `).join('')
        : '<div class="rc117-empty">No inspections scheduled for today.</div>';
    }

    if (recentList) {
      recentList.innerHTML = recentlyCompleted.length
        ? recentlyCompleted.map(project => `
            <button type="button" class="rc117-row" data-open-project="${escapeHtml(project.id)}">
              <span>
                <strong>${escapeHtml(projectTitle(project))}</strong>
                <small>${escapeHtml(projectClient(project))} · ${formatDate(project.completedAt || project.archivedAt || project.inspectionDate)}</small>
              </span>
              <em>View</em>
            </button>
          `).join('')
        : '<div class="rc117-empty">No completed inspections yet.</div>';
    }

    panel.querySelectorAll('[data-open-project]').forEach(button => {
      if (button.dataset.rc117Bound === 'true') return;
      button.dataset.rc117Bound = 'true';
      button.addEventListener('click', () => openInspection(button.dataset.openProject));
    });
  }

  function injectStyles() {
    if (document.getElementById('rc117Styles')) return;
    const style = document.createElement('style');
    style.id = 'rc117Styles';
    style.textContent = `
      .rc117-operational-dashboard{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px;margin:16px 0;}
      .rc117-op-card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:14px;box-shadow:0 4px 14px rgba(15,23,42,.06);}
      .rc117-op-heading{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:10px;}
      .rc117-op-heading h3{margin:2px 0 0;color:#111827;font-size:1rem;}
      .rc117-kicker{font-size:.72rem;font-weight:900;text-transform:uppercase;letter-spacing:.06em;color:#b71c1c;}
      .rc117-count{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;border-radius:999px;background:#b71c1c;color:white;font-weight:900;}
      .rc117-list{display:grid;gap:8px;}
      .rc117-row{width:100%;max-width:none;display:flex;justify-content:space-between;align-items:center;gap:12px;text-align:left;background:#f8fafc;color:#111827;border:1px solid #e2e8f0;border-left:5px solid #b71c1c;border-radius:12px;padding:10px 12px;}
      .rc117-row:hover,.rc117-row:focus{background:#fff5f5;border-color:#b71c1c;opacity:1;}
      .rc117-row strong{display:block;color:#111827;font-size:.95rem;}
      .rc117-row small{display:block;margin-top:3px;color:#64748b;font-weight:700;line-height:1.25;}
      .rc117-row em{font-style:normal;font-weight:900;color:#b71c1c;white-space:nowrap;}
      .rc117-empty{padding:12px;border-radius:12px;background:#f8fafc;border:1px dashed #cbd5e1;color:#64748b;font-weight:800;}
      .rc117-hidden-inactive{display:none!important;}
    `;
    document.head.appendChild(style);
  }

  function syncInspectionCommandContext() {
    const projects = safeProjects();
    const activeId = window.currentProjectId || (typeof currentProjectId !== 'undefined' ? currentProjectId : null);
    const project = projects.find(item => item.id === activeId);

    const companyEl = document.getElementById('inspectionCommandCompany');
    const siteEl = document.getElementById('inspectionCommandSite');

    if (!project) {
      if (companyEl) companyEl.textContent = 'No active inspection';
      if (siteEl) siteEl.textContent = 'Select premises';
      return;
    }

    if (companyEl) companyEl.textContent = projectClient(project);
    if (siteEl) siteEl.textContent = projectTitle(project);
  }

  function clearInspectionTransientPanels() {
    const reportSection = document.getElementById('reportSection');
    const reportContent = document.getElementById('reportContent');
    const analyticsSection = document.getElementById('analyticsSection');

    if (reportSection) reportSection.style.display = 'none';
    if (reportContent) reportContent.innerHTML = '';
    if (analyticsSection) analyticsSection.style.display = 'none';
  }

  function installContextWrappers() {
    if (window.__rc117ContextWrapped) return;
    window.__rc117ContextWrapped = true;

    const originalOpenProject = window.openProject;
    if (typeof originalOpenProject === 'function') {
      window.openProject = function rc117OpenProject(projectId, focusMode) {
        clearInspectionTransientPanels();
        const result = originalOpenProject.apply(this, arguments);
        setTimeout(syncInspectionCommandContext, 0);
        setTimeout(syncInspectionCommandContext, 250);
        return result;
      };
    }

    const originalCreateNewProject = window.createNewProject;
    if (typeof originalCreateNewProject === 'function') {
      window.createNewProject = function rc117CreateNewProject() {
        clearInspectionTransientPanels();
        const result = originalCreateNewProject.apply(this, arguments);
        setTimeout(() => {
          const companyEl = document.getElementById('inspectionCommandCompany');
          const siteEl = document.getElementById('inspectionCommandSite');
          if (companyEl) companyEl.textContent = 'New inspection';
          if (siteEl) siteEl.textContent = 'Unsaved premises';
        }, 0);
        return result;
      };
    }
  }

  function buildBlankInspectionShell(project) {
    return {
      ...project,
      inspectionNumber: (typeof generateInspectionNumber === 'function') ? generateInspectionNumber() : `INS-${Date.now()}`,
      inspectionDate: new Date().toISOString().slice(0, 10),
      completedAt: null,
      archivedAt: null,
      archiveStatus: '',
      scheduledDate: '',
      scheduledStatus: 'no_active_inspection',
      scheduleFreshInspection: false,
      scheduledReason: '',
      scheduleType: '',
      answers: [],
      photos: [],
      finalComments: '',
      followUpRequired: 'No',
      followUpDate: '',
      followUpNotes: '',
      repeatFindings: [],
      followUpFindingMode: false,
      followUpFindingIndexes: [],
      currentInspectionStatus: 'No active inspection',
      lastInspectionDeletedAt: new Date().toISOString(),
      syncPending: true,
      syncError: false,
      lastSaved: new Date().toISOString()
    };
  }

  function restorePreviousInspection(project) {
    const history = Array.isArray(project.inspectionHistory) ? project.inspectionHistory : [];
    if (!history.length) return buildBlankInspectionShell(project);

    const previous = history[history.length - 1] || {};
    const remainingHistory = history.slice(0, -1);

    return {
      ...project,
      ...previous,
      id: project.id,
      siteId: project.siteId,
      companyId: project.companyId,
      companyName: project.companyName,
      createdByUserId: project.createdByUserId,
      createdByEmail: project.createdByEmail,
      inspectionHistory: remainingHistory,
      scheduledDate: '',
      scheduledStatus: previous.completedAt ? 'completed' : 'restored',
      scheduleFreshInspection: false,
      scheduledReason: '',
      scheduleType: previous.scheduleType || project.scheduleType || '',
      restoredFromHistoryAt: new Date().toISOString(),
      syncPending: true,
      syncError: false,
      lastSaved: new Date().toISOString()
    };
  }

  async function safeDeleteInspectionOnly(event) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    }

    try {
      if (typeof canEditInspection === 'function' && !canEditInspection()) {
        alert('Your company access does not allow deleting inspections.');
        return;
      }
    } catch (error) {
      // Continue in local mode.
    }

    const activeId = window.currentProjectId || (typeof currentProjectId !== 'undefined' ? currentProjectId : null);
    if (!activeId) {
      const msg = document.getElementById('saveMessage');
      if (msg) msg.textContent = 'Open an inspection before using Delete Inspection.';
      return;
    }

    const projects = safeProjects();
    const index = projects.findIndex(project => project.id === activeId);
    if (index === -1) {
      alert('Active inspection was not found. Sync / refresh and try again.');
      return;
    }

    const project = projects[index];
    const hasHistory = Array.isArray(project.inspectionHistory) && project.inspectionHistory.length > 0;
    const message = hasHistory
      ? 'Delete only the current/latest inspection for this premises?\n\nThe premises, Building Passport and previous inspection history will remain.'
      : 'Delete the current inspection data but keep this premises/Building Passport?\n\nThis will clear checklist answers, photos and report data, but the premises will remain.';

    if (!confirm(message)) return;

    const updated = restorePreviousInspection(project);
    projects[index] = updated;
    saveProjects(projects);

    try {
      if (typeof currentProjectId !== 'undefined') currentProjectId = updated.id;
      window.currentProjectId = updated.id;
      if (typeof currentProject !== 'undefined') currentProject = updated;
      window.currentProject = updated;
      if (Array.isArray(updated.photos)) window.currentPhotos = updated.photos;
      if (typeof currentPhotos !== 'undefined') currentPhotos = updated.photos || [];
    } catch (error) {
      console.warn('RC117: could not update global context.', error);
    }

    try {
      if (navigator.onLine && typeof uploadSingleInspection === 'function') {
        uploadSingleInspection(updated).catch(error => console.warn('RC117: inspection-only delete upload failed.', error));
      }
    } catch (error) {
      console.warn('RC117: upload after delete failed.', error);
    }

    try {
      if (typeof renderProjectsList === 'function') renderProjectsList();
      if (typeof openProject === 'function') openProject(updated.id, '');
    } catch (error) {
      console.warn('RC117: reopen after delete failed.', error);
    }

    const msg = document.getElementById('saveMessage');
    if (msg) {
      msg.textContent = hasHistory
        ? 'Current inspection deleted. Previous inspection restored; premises kept.'
        : 'Inspection data cleared. Premises and Building Passport kept.';
    }
  }

  function installSafeDeleteButton() {
    const btn = document.getElementById('deleteBtn');
    if (!btn || btn.dataset.rc117SafeDelete === 'true') return;

    const replacement = btn.cloneNode(true);
    replacement.dataset.rc117SafeDelete = 'true';
    replacement.textContent = 'Delete Inspection';
    replacement.addEventListener('click', safeDeleteInspectionOnly, true);
    btn.parentNode.replaceChild(replacement, btn);

    window.deleteProject = safeDeleteInspectionOnly;
  }

  function installScrollStability() {
    if (window.__rc117ScrollStable) return;
    window.__rc117ScrollStable = true;

    document.addEventListener('change', event => {
      const target = event.target;
      if (!target || !target.classList || !target.classList.contains('answer-select')) return;

      const y = window.scrollY;
      const activeRow = target.closest('.checklist-row');

      setTimeout(() => {
        if (activeRow && document.body.contains(activeRow)) {
          const rowTop = activeRow.getBoundingClientRect().top;
          if (Math.abs(window.scrollY - y) > 120 && rowTop > -80) {
            window.scrollTo({ top: y, behavior: 'auto' });
          }
        }
      }, 80);
    }, true);

    document.addEventListener('input', event => {
      if (!event.target || !event.target.closest) return;
      if (!event.target.closest('#projectFormSection')) return;
      try {
        localStorage.setItem('fireSLastInspectionScroll', String(window.scrollY || 0));
      } catch (error) {}
    }, true);
  }

  function hideKnownInactivePlaceholders() {
    // Do not hide working inspection/report controls. Only remove empty placeholder panels.
    document.querySelectorAll('.placeholder, [data-placeholder="true"]').forEach(el => {
      el.classList.add('rc117-hidden-inactive');
    });
  }

  function refreshAll() {
    injectStyles();
    installContextWrappers();
    installSafeDeleteButton();
    installScrollStability();
    hideKnownInactivePlaceholders();
    renderOperationalDashboard();
    syncInspectionCommandContext();
  }

  function boot() {
    refreshAll();
    setTimeout(refreshAll, 300);
    setTimeout(refreshAll, 1200);

    const originalRender = window.renderHomeCommandCentre;
    if (typeof originalRender === 'function' && !originalRender.__rc117Wrapped) {
      const wrapped = function rc117RenderHomeCommandCentre() {
        const result = originalRender.apply(this, arguments);
        setTimeout(renderOperationalDashboard, 0);
        return result;
      };
      wrapped.__rc117Wrapped = true;
      window.renderHomeCommandCentre = wrapped;
    }

    console.log(`Fire-S ${HOTFIX_VERSION} loaded.`);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
