Fire-S RC Stability Patch v117

Upload these files directly to the GitHub repo root:
- index.html
- app.js
- styles.css
- rc-stability-hotfix.js
- service-worker.js

Fixes included:
- Correct file mapping: HTML stays in index.html, JavaScript stays in app.js, CSS stays in styles.css.
- Delete Inspection no longer deletes the whole premises record.
- If history exists, the previous inspection is restored and premises stays.
- If no history exists, inspection data is cleared but premises/Building Passport stays.
- Home Command Centre shows Scheduled Today and Last 5 Completed Inspections.
- Command Centre context is refreshed when opening/creating inspections.
- Findings/checklist answer selection is stabilised to reduce random jumps.

After upload, open:
https://georgevdx.github.io/fireye-online-app/?v=117

Then do a hard refresh.
