Fire-S v124 RC Safe Delete & Context Reset

Changed files:
- index.html
- app.js
- service-worker.js

What changed:
1. Delete Inspection no longer removes the project/premises row.
2. Delete Inspection clears only the active inspection cycle fields:
   answers, photos, comments, follow-up/schedule state and current inspection metadata.
3. Inspection History is preserved.
4. Delete no longer writes to fireyeDeletedProjectIds.
5. New Inspection and Open Inspection now reset runtime state before loading a context.
6. App/cache version updated to v124-rc-safe-delete-context.

Test first after import backup confirms 57 inspections.
