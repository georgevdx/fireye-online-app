/* Fire-S Hotfix 203B - Safe Data Load Checker
   Loads before app.js and validates known JSON data files.
*/
(function () {
  'use strict';

  if (window.fireSDataLoadCheckerApplied) return;
  window.fireSDataLoadCheckerApplied = true;

  var JSON_FILE_PATTERN = /(?:^|\/)(checklists|rules|requirements|occupancies|templates)\.json(?:\?|$)/i;
  var originalFetch = window.fetch ? window.fetch.bind(window) : null;

  function getUrl(input) {
    if (typeof input === 'string') return input;
    if (input && typeof input.url === 'string') return input.url;
    return '';
  }

  function fileNameFromUrl(url) {
    return (String(url || '').split('/').pop() || String(url || '')).split('?')[0];
  }

  function startsLikeJavaScript(text) {
    var sample = String(text || '').trim().slice(0, 80);
    return /^(let|const|var|function|class|import|export)\b/.test(sample) || sample.indexOf('/*') === 0;
  }

  function startsLikeHtml(text) {
    var sample = String(text || '').trim().slice(0, 80).toLowerCase();
    return sample.indexOf('<!doctype') === 0 || sample.indexOf('<html') === 0;
  }

  function showDataLoadError(fileName, detail) {
    var message = 'App data failed to load\n' + fileName + ' ' + detail + '\n\nFix: replace this JSON file with the correct .json file, then press Ctrl + F5.';

    function render() {
      var host = document.getElementById('homeSection') || document.body;
      var panel = document.getElementById('fireSDataLoadErrorPanel');

      if (!panel) {
        panel = document.createElement('div');
        panel.id = 'fireSDataLoadErrorPanel';
        panel.style.cssText = 'margin:16px;padding:14px;border:2px solid #b71c1c;border-radius:10px;background:#fff3f3;color:#4a0000;font-family:system-ui,Segoe UI,Arial,sans-serif;white-space:pre-wrap;z-index:99999;position:relative;';
        host.insertBefore(panel, host.firstChild);
      }

      panel.textContent = message;
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', render, { once: true });
    } else {
      render();
    }
  }

  if (!originalFetch) return;

  window.fetch = function fireSCheckedFetch(input, init) {
    var url = getUrl(input);

    return originalFetch(input, init).then(function (response) {
      if (!JSON_FILE_PATTERN.test(url)) {
        return response;
      }

      var clone = response.clone();
      var fileName = fileNameFromUrl(url);

      return clone.text().then(function (text) {
        if (startsLikeJavaScript(text)) {
          var jsMessage = 'returned JavaScript instead of JSON. The wrong file was uploaded or cached.';
          showDataLoadError(fileName, jsMessage);
          throw new Error(fileName + ' ' + jsMessage);
        }

        if (startsLikeHtml(text)) {
          var htmlMessage = 'returned HTML instead of JSON. Check the file path and upload location.';
          showDataLoadError(fileName, htmlMessage);
          throw new Error(fileName + ' ' + htmlMessage);
        }

        try {
          JSON.parse(text);
        } catch (error) {
          var jsonMessage = 'is not valid JSON. ' + (error && error.message ? error.message : '');
          showDataLoadError(fileName, jsonMessage);
          throw new Error(fileName + ' ' + jsonMessage);
        }

        return response;
      });
    });
  };
})();
